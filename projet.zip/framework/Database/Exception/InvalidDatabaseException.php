<?php

namespace Framework\Database\Exception;

class InvalidDatabaseException extends \PDOException
{

}