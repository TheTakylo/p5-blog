<?php
namespace Framework\Templating\Exception;

use Framework\Templating\Exception\TemplateException;

class TemplateNotFoundException extends TemplateException
{
    
}