<?php

namespace Framework\Templating\Exception;

abstract class TemplateException extends \RuntimeException
{

}