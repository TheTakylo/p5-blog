<?php
namespace Framework\Templating\Exception;

use Framework\Templating\Exception\TemplateException;

class PartialNotFoundException extends TemplateException
{
    
}