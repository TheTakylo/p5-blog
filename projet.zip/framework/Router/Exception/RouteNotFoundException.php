<?php

namespace Framework\Router\Exception;

class RouteNotFoundException extends \RuntimeException
{
    
}