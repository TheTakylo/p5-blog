<?php

namespace Framework\Form\Type;

class TextType extends AbstractType
{
}