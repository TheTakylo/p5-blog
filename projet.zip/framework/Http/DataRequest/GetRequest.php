<?php

namespace Framework\Http\DataRequest;

class GetRequest extends AbstractDataRequest
{
}