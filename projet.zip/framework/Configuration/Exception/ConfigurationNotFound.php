<?php

namespace Framework\Configuration\Exception;

class ConfigurationNotFound extends \RuntimeException
{
    
}